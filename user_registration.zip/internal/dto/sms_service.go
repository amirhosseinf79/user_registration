package dto

type FieldSmsSendClient struct {
	FieldAuthSendOTP
	Text string
}
