package model

type OTP struct {
	Mobile string `json:"mobile"`
	Code   string `json:"code"`
}
